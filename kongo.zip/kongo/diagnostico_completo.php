<?php
/**
 * Diagnóstico Completo - Kongo Arena
 */

header('Content-Type: text/html; charset=utf-8');
echo "<pre style='background:#0a0a0a; color:#00ff00; font-family:monospace; padding:20px; font-size:13px;'>";
echo "🔍 DIAGNÓSTICO COMPLETO - KONGO ARENA\n";
echo "=====================================\n\n";

// 1. Verificar arquivo de configuração do banco
echo "📁 1. Verificando arquivo de configuração do banco...\n";
$dbFile = __DIR__ . '/api/config/database.php';
if (file_exists($dbFile)) {
    echo "   ✅ Ficheiro encontrado: api/config/database.php\n";
    
    // Mostrar o conteúdo (sem senhas)
    $content = file_get_contents($dbFile);
    $content = preg_replace('/(password|pass|senha)\s*[\'"]?\s*=>\s*[\'"][^\'"]+[\'"]/', '$1 => \'***OCULTO***\'', $content);
    echo "   📄 Conteúdo:\n";
    foreach (explode("\n", $content) as $line) {
        echo "      " . trim($line) . "\n";
    }
} else {
    echo "   ❌ Ficheiro NÃO encontrado!\n";
}
echo "\n";

// 2. Tentar conectar ao banco
echo "🔌 2. Tentando conectar ao banco de dados...\n";
try {
    // Tentar diferentes formas de carregar a configuração
    if (file_exists($dbFile)) {
        $config = require $dbFile;
        
        if (is_array($config)) {
            // Formato array de configuração
            $host = $config['host'] ?? 'localhost';
            $dbname = $config['db'] ?? $config['dbname'] ?? $config['database'] ?? '';
            $user = $config['user'] ?? $config['username'] ?? '';
            $pass = $config['pass'] ?? $config['password'] ?? '';
            
            echo "   Host: $host\n";
            echo "   Database: $dbname\n";
            echo "   User: $user\n";
            
            $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
            $pdo = new PDO($dsn, $user, $pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            echo "   ✅ Conexão estabelecida com sucesso!\n";
        } elseif ($config instanceof PDO) {
            $pdo = $config;
            echo "   ✅ Conexão PDO retornada diretamente!\n";
        } else {
            echo "   ⚠️ Formato desconhecido do retorno do database.php\n";
            echo "   Tipo: " . gettype($config) . "\n";
        }
    } else {
        // Tentar conectar manualmente (ajuste conforme necessário)
        echo "   ⚠️ Tentando conexão manual...\n";
        $pdo = new PDO('mysql:host=localhost;dbname=SEU_BANCO', 'SEU_USER', 'SUA_SENHA');
        echo "   ✅ Conexão manual estabelecida!\n";
    }
} catch (Exception $e) {
    echo "   ❌ Erro na conexão: " . $e->getMessage() . "\n";
    echo "</pre>";
    exit;
}
echo "\n";

// 3. Verificar usuários no banco
echo "👥 3. Verificando usuários na tabela cong_utilizadores...\n";
try {
    $stmt = $pdo->query("SELECT id, nome_completo, email, tipo, status FROM cong_utilizadores ORDER BY id DESC LIMIT 10");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($users) > 0) {
        echo "   ✅ " . count($users) . " utilizador(es) encontrado(s):\n\n";
        foreach ($users as $u) {
            $icon = $u['tipo'] === 'admin' ? '👑' : '👤';
            echo "   $icon ID: {$u['id']} | {$u['nome_completo']} | {$u['email']} | Tipo: {$u['tipo']} | Status: {$u['status']}\n";
        }
    } else {
        echo "   ❌ Nenhum utilizador encontrado!\n";
    }
} catch (Exception $e) {
    echo "   ❌ Erro: " . $e->getMessage() . "\n";
}
echo "\n";

// 4. Criar admin de teste se não existir
echo "🛠️ 4. Verificando/Criando Admin de Teste...\n";
try {
    $stmt = $pdo->prepare("SELECT id FROM cong_utilizadores WHERE tipo = 'admin' LIMIT 1");
    $stmt->execute();
    $admin = $stmt->fetch();
    
    if ($admin) {
        echo "   ✅ Admin já existe (ID: {$admin['id']})\n";
    } else {
        echo "   ⚠️ Nenhum admin encontrado. Criando admin de teste...\n";
        
        $stmt = $pdo->prepare("
            INSERT INTO cong_utilizadores 
            (nome_completo, email, telefone, senha_hash, tipo, status, criado_em) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $adminData = [
            'nome_completo' => 'Administrador Kongo',
            'email' => 'admin@kongo.com',
            'telefone' => '911111111',
            'senha_hash' => password_hash('admin123', PASSWORD_DEFAULT),
            'tipo' => 'admin',
            'status' => 'ativo'
        ];
        
        $stmt->execute([
            $adminData['nome_completo'],
            $adminData['email'],
            $adminData['telefone'],
            $adminData['senha_hash'],
            $adminData['tipo'],
            $adminData['status']
        ]);
        
        echo "   ✅ Admin criado com sucesso!\n";
        echo "   📧 Email: admin@kongo.com\n";
        echo "   🔑 Senha: admin123\n";
    }
} catch (Exception $e) {
    echo "   ❌ Erro: " . $e->getMessage() . "\n";
}
echo "\n";

// 5. Testar login via API
echo "🔐 5. Testando login via API...\n";
try {
    $loginData = json_encode([
        'email' => 'admin@kongo.com',
        'senha' => 'admin123'
    ]);
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://' . $_SERVER['HTTP_HOST'] . '/api/index.php?rota=login');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $loginData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($loginData)
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "   HTTP Code: $httpCode\n";
    $result = json_decode($response, true);
    
    if ($result && isset($result['success'])) {
        if ($result['success']) {
            echo "   ✅ Login bem-sucedido!\n";
            if (isset($result['token'])) {
                echo "   🔑 Token gerado: " . substr($result['token'], 0, 50) . "...\n";
            }
            if (isset($result['utilizador']) || isset($result['user'])) {
                $user = $result['utilizador'] ?? $result['user'];
                echo "   👤 Utilizador: " . json_encode($user) . "\n";
            }
        } else {
            echo "   ❌ Login falhou: " . ($result['message'] ?? 'Erro desconhecido') . "\n";
        }
    } else {
        echo "   ⚠️ Resposta da API: $response\n";
    }
} catch (Exception $e) {
    echo "   ❌ Erro ao testar API: " . $e->getMessage() . "\n";
}
echo "\n";

// 6. Verificar estrutura da tabela cong_utilizadores
echo "📋 6. Estrutura da tabela cong_utilizadores...\n";
try {
    $stmt = $pdo->query("DESCRIBE cong_utilizadores");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($columns as $col) {
        echo "   - {$col['Field']} ({$col['Type']}) {$col['Null']} {$col['Default']}\n";
    }
} catch (Exception $e) {
    echo "   ❌ Erro: " . $e->getMessage() . "\n";
}
echo "\n";

echo "=====================================\n";
echo "💡 PRÓXIMOS PASSOS:\n";
echo "1. Use as credenciais acima para fazer login\n";
echo "2. Verifique se o token está sendo salvo no navegador (F12 > Application > Local Storage)\n";
echo "3. DELETE este ficheiro após o diagnóstico\n";
echo "=====================================\n";
echo "</pre>";
?>