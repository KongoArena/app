<?php
echo "<pre>";
echo file_get_contents(__DIR__ . '/api/index.php');
echo "</pre>";
?>