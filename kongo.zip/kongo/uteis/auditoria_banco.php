<?php
// ⚠️ CONFIGURE AQUI SEUS DADOS DE ACESSO AO BANCO
$host = 'myshared2003';
$db   = 'luna_home';
$user = 'luna_home';
$pass = 'Akiles1539@@##';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

header('Content-Type: text/plain; charset=utf-8');
echo "=== ESTRUTURA DO BANCO DE DADOS ===\n\n";

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    
    foreach ($tables as $table) {
        echo "🗃️  TABELA: " . $table . "\n";
        echo str_repeat("-", 40) . "\n";
        $stmt = $pdo->query("SHOW COLUMNS FROM `$table`");
        while ($row = $stmt->fetch()) {
            echo "  - " . $row['Field'] . " | Tipo: " . $row['Type'] . " | " . ($row['Key'] == 'PRI' ? '🔑 PK' : '') . "\n";
        }
        echo "\n";
    }
    echo "=== FIM DA AUDITORIA DO BANCO ===\n";
} catch (\PDOException $e) {
    echo "❌ Erro ao conectar no banco: " . $e->getMessage() . "\n";
    echo "Verifique as credenciais no topo deste script.\n";
}
?>