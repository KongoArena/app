<?php
// ======================================================
// SCRIPT DE DIAGNÓSTICO - KONGO ARENA
// ======================================================

echo "<h1>🔍 Diagnóstico da Kongo Arena</h1>";
echo "<hr>";

// 1. INFORMAÇÕES DO SERVIDOR
echo "<h2>🖥️ Informações do Servidor</h2>";
echo "<ul>";
echo "<li><strong>PHP Version:</strong> " . phpversion() . "</li>";
echo "<li><strong>Servidor:</strong> " . $_SERVER['SERVER_SOFTWARE'] . "</li>";
echo "<li><strong>IP do Servidor:</strong> " . $_SERVER['SERVER_ADDR'] . "</li>";
echo "<li><strong>Document Root:</strong> " . $_SERVER['DOCUMENT_ROOT'] . "</li>";
echo "<li><strong>Script atual:</strong> " . __FILE__ . "</li>";
echo "</ul>";

// 2. VERIFICAR EXTENSÕES PHP
echo "<h2>📦 Extensões PHP Necessárias</h2>";
$extensoes = ['pdo', 'pdo_mysql', 'json', 'mbstring', 'gd', 'curl', 'openssl'];
echo "<ul>";
foreach ($extensoes as $ext) {
    $status = extension_loaded($ext) ? '✅' : '❌';
    echo "<li>$status $ext</li>";
}
echo "</ul>";

// 3. TESTE DE CONEXÃO COM O BANCO DE DADOS
echo "<h2>🗄️ Conexão com Banco de Dados</h2>";
try {
    $host = 'myshared2003';
    $dbname = 'luna_home';
    $user = 'luna_home';
    $pass = 'Akiles1539@@##';
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<p style='color:green;'>✅ Conexão com o banco de dados estabelecida com sucesso!</p>";
    
    // Verificar tabelas
    echo "<h3>📋 Tabelas criadas</h3>";
    $stmt = $pdo->query("SHOW TABLES LIKE 'cong_%'");
    $tabelas = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    if (count($tabelas) > 0) {
        echo "<ul>";
        foreach ($tabelas as $tabela) {
            echo "<li>✅ $tabela</li>";
        }
        echo "</ul>";
        echo "<p>Total: <strong>" . count($tabelas) . "</strong> tabelas encontradas.</p>";
    } else {
        echo "<p style='color:orange;'>⚠️ Nenhuma tabela com prefixo 'cong_' encontrada.</p>";
        echo "<p>Executa o script SQL para criar as tabelas.</p>";
    }
    
    // Verificar dados iniciais
    echo "<h3>📊 Dados Iniciais</h3>";
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM cong_modalidades");
    $modalidades = $stmt->fetch()['total'];
    echo "<p>Modalidades: <strong>$modalidades</strong></p>";
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM cong_temporadas");
    $temporadas = $stmt->fetch()['total'];
    echo "<p>Temporadas: <strong>$temporadas</strong></p>";
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM cong_utilizadores");
    $utilizadores = $stmt->fetch()['total'];
    echo "<p>Utilizadores: <strong>$utilizadores</strong></p>";
    
} catch (PDOException $e) {
    echo "<p style='color:red;'>❌ Erro de conexão: " . $e->getMessage() . "</p>";
    echo "<p>Verifique as credenciais no arquivo config/database.php</p>";
}

// 4. VERIFICAR ESTRUTURA DE PASTAS
echo "<h2>📁 Estrutura de Pastas</h2>";
$pastas = ['api', 'api/config', 'api/models', 'api/controllers', 'api/middleware', 'admin', 'admin/css', 'admin/js'];
echo "<ul>";
foreach ($pastas as $pasta) {
    if (is_dir($pasta)) {
        echo "<li>✅ $pasta/</li>";
    } else {
        echo "<li>❌ $pasta/ - <span style='color:red;'>Não encontrada</span></li>";
    }
}
echo "</ul>";

// 5. VERIFICAR ARQUIVOS IMPORTANTES
echo "<h2>📄 Arquivos Importantes</h2>";
$arquivos = [
    'api/index.php',
    'api/config/database.php',
    'api/config/jwt.php',
    'api/models/Atleta.php',
    'api/models/Utilizador.php',
    'api/controllers/AuthController.php',
    'api/controllers/AtletaController.php',
    'api/middleware/Auth.php',
    '.htaccess',
    'admin/login.html'
];
echo "<ul>";
foreach ($arquivos as $arquivo) {
    if (file_exists($arquivo)) {
        echo "<li>✅ $arquivo</li>";
    } else {
        echo "<li>❌ $arquivo - <span style='color:red;'>Não encontrado</span></li>";
    }
}
echo "</ul>";

// 6. TESTE DE PERMISSÕES
echo "<h2>🔐 Permissões de Arquivos</h2>";
$testarPermissao = ['api/index.php', '.htaccess', 'admin/login.html'];
echo "<ul>";
foreach ($testarPermissao as $arquivo) {
    if (file_exists($arquivo)) {
        $perms = substr(sprintf('%o', fileperms($arquivo)), -4);
        $legivel = is_readable($arquivo) ? '📖 Legível' : '🚫 Não legível';
        $gravel = is_writable($arquivo) ? '✏️ Gravável' : '🚫 Não gravável';
        echo "<li>$arquivo - Permissões: $perms | $legivel | $gravel</li>";
    }
}
echo "</ul>";

// 7. TESTE DE API (GET simples)
echo "<h2>🌐 Teste de API</h2>";
try {
    $url = "http://" . $_SERVER['HTTP_HOST'] . "/kongo/api/index.php";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode == 200) {
        echo "<p style='color:green;'>✅ API respondendo na URL: $url</p>";
        echo "<p>Resposta: " . htmlspecialchars(substr($response, 0, 200)) . "...</p>";
    } else {
        echo "<p style='color:orange;'>⚠️ API retornou código HTTP: $httpCode</p>";
        echo "<p>URL testada: $url</p>";
    }
} catch (Exception $e) {
    echo "<p style='color:red;'>❌ Erro ao testar API: " . $e->getMessage() . "</p>";
}

// 8. TESTE DE CREDENCIAIS DO BANCO
echo "<h2>🔑 Credenciais do Banco</h2>";
echo "<p><strong>Host:</strong> localhost</p>";
echo "<p><strong>Banco:</strong> luna_home</p>";
echo "<p><strong>Usuário:</strong> luna_home</p>";
echo "<p><strong>Senha:</strong> " . str_repeat('•', strlen('Akiles1539@@##')) . "</p>";

// 9. SUGESTÕES FINAIS
echo "<h2>💡 Sugestões</h2>";
echo "<ul>";

// Verificar se o .htaccess existe
if (!file_exists('.htaccess')) {
    echo "<li>⚠️ O arquivo .htaccess não existe. Crie-o com as regras de reescrita.</li>";
}

// Verificar se as tabelas existem
if (isset($tabelas) && count($tabelas) == 0) {
    echo "<li>⚠️ Nenhuma tabela encontrada. Execute o script SQL completo.</li>";
}

// Verificar se o admin existe
if (isset($utilizadores) && $utilizadores == 0) {
    echo "<li>⚠️ Nenhum utilizador administrador encontrado. Crie um admin.</li>";
}

// Verificar permissões
echo "<li>🔧 Se houver erros 403, verifique as permissões das pastas (755) e arquivos (644).</li>";
echo "<li>🔧 Se houver erro 500, verifique os logs de erro do servidor.</li>";

echo "</ul>";

echo "<hr>";
echo "<p style='color:blue;'>📌 Diagnóstico concluído. Corre este script sempre que precisar de verificar o estado do sistema.</p>";
?>