<?php
/**
 * Kongo Arena - Script de Upgrade Automático (up_util.php)
 * Prepara o banco de dados e cria usuários de teste para o Painel do Cliente.
 * Desenvolvido por TanqueDigital (tanquedigital.com.br)
 */

header('Content-Type: text/html; charset=utf-8');
echo "<pre style='background:#1a1a1a; color:#00ff00; font-family:monospace; padding:30px; font-size:14px; line-height:1.5;'>";
echo "======================================================\n";
echo "   🚀 KONGO ARENA - UPGRADE DE SISTEMA (CLIENTE)   \n";
echo "======================================================\n\n";

// 1. TENTAR LER AS CREDENCIAIS AUTOMATICAMENTE DO SEU SISTEMA
$pdo = null;
if (file_exists(__DIR__ . '/api/config/database.php')) {
    echo "🔍 Arquivo 'api/config/database.php' encontrado. A tentar ler...\n";
    $config = require __DIR__ . '/api/config/database.php';
    
    if ($config instanceof PDO) {
        $pdo = $config;
        echo "✅ Instância PDO carregada com sucesso!\n\n";
    } elseif (is_array($config)) {
        $host = $config['host'] ?? 'localhost';
        $db   = $config['db'] ?? $config['database'] ?? $config['dbname'] ?? '';
        $user = $config['user'] ?? $config['username'] ?? '';
        $pass = $config['pass'] ?? $config['password'] ?? '';
    }
}

// 2. FALLBACK MANUAL (Caso o database.php não retorne o que esperamos)
if (!$pdo) {
    echo "⚠️ Não foi possível ler o PDO automaticamente. Use as credenciais manuais:\n";
    // ⚠️ EDITE AQUI APENAS SE O BANCO NÃO FOR DETECTADO AUTOMATICAMENTE
    $host = 'myshared2003';
    $db   = 'luna_home';
    $user = 'luna_home';
    $pass = 'Akiles1539@@##';
    
    try {
        $dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
        $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        echo "✅ Conexão manual estabelecida!\n\n";
    } catch (PDOException $e) {
        die("❌ Erro: " . $e->getMessage() . "\nPor favor, edite as variáveis no topo de up_util.php.\n");
    }
}

// 3. ATUALIZAR ESTRUTURA (Garantir que os novos perfis existem)
echo "🛠️ A atualizar a tabela 'cong_utilizadores'...\n";
try {
    $pdo->exec("ALTER TABLE `cong_utilizadores` 
                MODIFY COLUMN `tipo` ENUM('admin','gestor','equipa','atleta','scout','visitante') 
                DEFAULT 'visitante'");
    echo "✅ Campo 'tipo' atualizado para suportar 'gestor' e 'equipa'.\n";
} catch (Exception $e) {
    echo "ℹ️ Nota: " . $e->getMessage() . "\n";
}

// 4. CRIAR USUÁRIOS DE TESTE (Para você testar o login e ir dormir!)
echo "\n👤 A criar utilizadores de teste...\n";
$senhaHash = password_hash('123456', PASSWORD_DEFAULT);

// Admin
$stmt = $pdo->prepare("SELECT id FROM cong_utilizadores WHERE email = ?");
$stmt->execute(['admin@kongo.ao']);
if (!$stmt->fetch()) {
    $pdo->prepare("INSERT INTO cong_utilizadores (nome_completo, email, telefone, senha_hash, tipo, status, criado_em) 
                   VALUES (?, ?, ?, ?, ?, ?, NOW())")
        ->execute(['Administrador Kongo', 'admin@kongo.ao', '900000000', $senhaHash, 'admin', 'ativo']);
    echo "   ✅ Admin criado: admin@kongo.ao | Senha: 123456\n";
} else {
    echo "   ℹ️ Admin já existe.\n";
}

// Gestor (Cliente)
$stmt->execute(['gestor@kongo.ao']);
if (!$stmt->fetch()) {
    $pdo->prepare("INSERT INTO cong_utilizadores (nome_completo, email, telefone, senha_hash, tipo, status, criado_em) 
                   VALUES (?, ?, ?, ?, ?, ?, NOW())")
        ->execute(['Gestor do Clube FC', 'gestor@kongo.ao', '911111111', $senhaHash, 'gestor', 'ativo']);
    echo "   ✅ Gestor criado: gestor@kongo.ao | Senha: 123456\n";
} else {
    echo "   ℹ️ Gestor já existe.\n";
}

// 5. CRIAR CLUBE E EQUIPA DE TESTE
echo "\n🏛️ A criar Clube e Equipa de teste...\n";
$stmt = $pdo->prepare("SELECT id FROM cong_clubes WHERE email = ?");
$stmt->execute(['gestor@kongo.ao']);
$clube = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$clube) {
    $pdo->prepare("INSERT INTO cong_clubes (nome, cidade, responsavel, contacto, email, criado_em) 
                   VALUES (?, ?, ?, ?, ?, NOW())")
        ->execute(['FC Kongo Digital', 'Luanda', 'Gestor do Clube FC', '911111111', 'gestor@kongo.ao']);
    $clubeId = $pdo->lastInsertId();
    echo "   ✅ Clube 'FC Kongo Digital' criado (ID: $clubeId).\n";
} else {
    $clubeId = $clube['id'];
    echo "   ℹ️ Clube já existe (ID: $clubeId).\n";
}

$stmt = $pdo->prepare("SELECT id FROM cong_equipas WHERE clube_id = ?");
$stmt->execute([$clubeId]);
if (!$stmt->fetch()) {
    $pdo->prepare("INSERT INTO cong_equipas (nome, clube_id, modalidade_id, categoria, treinador, criado_em) 
                   VALUES (?, ?, 1, 'Sub-17', 'Treinador Teste', NOW())")
        ->execute(['Equipa Principal FC', $clubeId]);
    echo "   ✅ Equipa 'Equipa Principal FC' criada.\n";
} else {
    echo "   ℹ️ Equipa já existe.\n";
}

// 6. MENSAGEM FINAL
echo "\n======================================================\n";
echo "   🎉 UPGRADE CONCLUÍDO COM SUCESSO!   \n";
echo "======================================================\n\n";
echo "📌 PRÓXIMOS PASSOS (Agora vá dormir!):\n";
echo "1. DELETE este ficheiro (up_util.php) do servidor por segurança.\n";
echo "2. Vá para o 'login.html' e teste:\n";
echo "   - admin@kongo.ao / 123456  => Vai para o index.html\n";
echo "   - gestor@kongo.ao / 123456 => Vai para o cliente.html\n";
echo "\n💡 Nota: Certifique-se que o seu 'Utilizador.php' usa a função\n";
echo "   password_verify() para validar a senha no login.\n\n";
echo "------------------------------------------------------\n";
echo "Desenvolvido por TanqueDigital (tanquedigital.com.br)\n";
echo "------------------------------------------------------\n";
echo "</pre>";
?>