<?php
// Evita timeout em servidores lentos
set_time_limit(60);

function listarArquivos($dir, $prefix = '') {
    // Ignora pastas de sistema e dependências pesadas
    $ignore = ['.', '..', 'node_modules', '.git', 'vendor', 'auditoria_arquivos.php', 'auditoria_banco.php'];
    $items = scandir($dir);
    
    foreach ($items as $item) {
        if (in_array($item, $ignore)) continue;
        
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path)) {
            echo $prefix . "📁 " . $item . "/\n";
            listarArquivos($path, $prefix . "   ");
        } else {
            $size = round(filesize($path) / 1024, 2);
            echo $prefix . "📄 " . $item . " (" . $size . " KB)\n";
        }
    }
}

header('Content-Type: text/plain; charset=utf-8');
echo "=== ESTRUTURA DE ARQUIVOS DO KONGO ARENA ===\n\n";
listarArquivos(__DIR__);
echo "\n=== FIM DA AUDITORIA DE ARQUIVOS ===\n";
?>