<?php
/**
 * LOGIN DE EMERGÊNCIA - Kongo Arena
 * Versão corrigida - Suporte a AJAX e Login Direto
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Configuração do banco
$host = 'myshared2003';
$dbname = 'luna_home';
$user = 'luna_home';
$pass = 'Akiles1539@@##';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    if ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') {
        echo json_encode(['success' => false, 'message' => 'Erro no banco: ' . $e->getMessage()]);
        exit;
    }
    die("❌ Erro de conexão: " . $e->getMessage());
}

// Se for requisição AJAX (login via fetch)
if ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    $response = ['success' => false, 'message' => 'Credenciais inválidas'];
    
    if (!empty($username) && !empty($password)) {
        try {
            // Buscar usuário por username ou email
            $stmt = $pdo->prepare("SELECT * FROM cong_utilizadores WHERE username = ? OR email = ?");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user) {
                // Verificar senha (campo é 'senha_hash')
                if (password_verify($password, $user['senha_hash'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['tipo'] = $user['tipo'];
                    $_SESSION['nome'] = $user['nome_completo'];
                    
                    $response = [
                        'success' => true,
                        'message' => 'Login bem sucedido!',
                        'user' => [
                            'id' => $user['id'],
                            'username' => $user['username'],
                            'email' => $user['email'],
                            'tipo' => $user['tipo'],
                            'nome' => $user['nome_completo']
                        ]
                    ];
                } else {
                    $response['message'] = 'Senha incorreta!';
                }
            } else {
                $response['message'] = 'Usuário não encontrado!';
            }
        } catch (PDOException $e) {
            $response['message'] = 'Erro: ' . $e->getMessage();
        }
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// Se for requisição normal (GET) - mostrar página HTML
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Se já estiver logado, redirecionar
    if (isset($_SESSION['user_id'])) {
        header('Location: admin/dashboard.html');
        exit;
    }
    
    // Mostrar página de login
    $usuarios = $pdo->query("SELECT id, username, email, tipo, nome_completo FROM cong_utilizadores")->fetchAll(PDO::FETCH_ASSOC);
    ?>
    
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>🔐 Login de Emergência - Kongo Arena</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: 'Segoe UI', sans-serif;
                background: linear-gradient(135deg, #0a0a1a 0%, #1a1a3e 100%);
                min-height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
                padding: 20px;
            }
            .container {
                background: #16213e;
                padding: 40px;
                border-radius: 20px;
                max-width: 500px;
                width: 100%;
                box-shadow: 0 20px 60px rgba(0,0,0,0.8);
                border-left: 5px solid #e94560;
            }
            h1 {
                color: #e94560;
                font-size: 28px;
                text-align: center;
                margin-bottom: 10px;
            }
            .subtitle {
                color: #4fc3f7;
                text-align: center;
                margin-bottom: 30px;
                font-size: 14px;
            }
            .form-group {
                margin-bottom: 20px;
            }
            label {
                display: block;
                color: #eee;
                margin-bottom: 5px;
                font-weight: bold;
            }
            input {
                width: 100%;
                padding: 12px 15px;
                border: none;
                border-radius: 8px;
                background: #0f3460;
                color: #fff;
                font-size: 16px;
            }
            input:focus {
                outline: none;
                box-shadow: 0 0 0 2px #e94560;
            }
            button {
                width: 100%;
                padding: 14px;
                background: #e94560;
                color: #fff;
                border: none;
                border-radius: 8px;
                font-size: 18px;
                font-weight: bold;
                cursor: pointer;
                transition: all 0.3s;
            }
            button:hover {
                background: #c73652;
                transform: translateY(-2px);
            }
            .erro {
                background: #4a0a0a;
                color: #e94560;
                padding: 12px;
                border-radius: 8px;
                margin-bottom: 20px;
                border-left: 3px solid #e94560;
                display: none;
            }
            .info-box {
                background: #0f3460;
                padding: 15px;
                border-radius: 8px;
                margin-top: 20px;
                border-left: 3px solid #4fc3f7;
            }
            .info-box h3 {
                color: #4fc3f7;
                margin-bottom: 10px;
                font-size: 14px;
            }
            .usuario-item {
                color: #4ecca3;
                font-size: 13px;
                padding: 3px 0;
            }
            .badge {
                display: inline-block;
                padding: 2px 10px;
                border-radius: 12px;
                font-size: 11px;
                font-weight: bold;
            }
            .badge-admin { background: #e94560; color: #fff; }
            .badge-gestor { background: #f5a623; color: #000; }
            .badge-atleta { background: #4fc3f7; color: #000; }
            .badge-default { background: #666; color: #fff; }
            .footer {
                text-align: center;
                margin-top: 20px;
                color: #666;
                font-size: 12px;
            }
            .link-ajuda {
                display: block;
                text-align: center;
                margin-top: 15px;
                color: #4fc3f7;
                text-decoration: none;
                font-size: 14px;
            }
            .link-ajuda:hover { text-decoration: underline; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🔐 Login de Emergência</h1>
            <p class="subtitle">Kongo Arena - Acesso Alternativo</p>
            
            <div id="erro" class="erro">⚠️ Erro no login</div>
            
            <form id="formLogin">
                <div class="form-group">
                    <label>👤 Usuário ou Email</label>
                    <input type="text" id="username" placeholder="Digite seu usuário" required autofocus>
                </div>
                
                <div class="form-group">
                    <label>🔑 Senha</label>
                    <input type="password" id="password" placeholder="Digite sua senha" required>
                </div>
                
                <button type="submit">🚀 Entrar no Sistema</button>
            </form>
            
            <div class="info-box">
                <h3>📋 USUÁRIOS CADASTRADOS</h3>
                <?php foreach ($usuarios as $u): 
                    $badge_class = 'default';
                    if ($u['tipo'] == 'admin') $badge_class = 'admin';
                    elseif ($u['tipo'] == 'gestor') $badge_class = 'gestor';
                    elseif ($u['tipo'] == 'atleta') $badge_class = 'atleta';
                ?>
                    <p class="usuario-item">
                        👤 <?php echo htmlspecialchars($u['username'] ?? $u['email']); ?> 
                        (<?php echo htmlspecialchars($u['email']); ?>)
                        <span class="badge badge-<?php echo $badge_class; ?>">
                            <?php echo htmlspecialchars($u['tipo']); ?>
                        </span>
                    </p>
                <?php endforeach; ?>
            </div>
            
            <div class="info-box" style="border-left-color: #4ecca3;">
                <h3>💡 CREDENCIAIS PADRÃO</h3>
                <p style="color:#4ecca3;">👤 admin | 🔑 admin123</p>
            </div>
            
            <a href="admin/login.html" class="link-ajuda">← Voltar para o login padrão</a>
            
            <div class="footer">
                Kongo Arena v1.0 - Login de Emergência
            </div>
        </div>

        <script>
            document.getElementById('formLogin').addEventListener('submit', function(e) {
                e.preventDefault();
                
                const username = document.getElementById('username').value.trim();
                const password = document.getElementById('password').value.trim();
                const erroDiv = document.getElementById('erro');
                
                if (!username || !password) {
                    erroDiv.textContent = '⚠️ Preencha todos os campos!';
                    erroDiv.style.display = 'block';
                    return;
                }
                
                // Enviar requisição AJAX
                fetch(window.location.href, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: 'username=' + encodeURIComponent(username) + '&password=' + encodeURIComponent(password)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Login bem sucedido
                        window.location.href = 'admin/dashboard.html';
                    } else {
                        erroDiv.textContent = '⚠️ ' + data.message;
                        erroDiv.style.display = 'block';
                    }
                })
                .catch(() => {
                    erroDiv.textContent = '⚠️ Erro ao conectar com o servidor!';
                    erroDiv.style.display = 'block';
                });
            });
        </script>
    </body>
    </html>
    <?php
    exit;
}

// Se for POST normal (não AJAX)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (!empty($username) && !empty($password)) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM cong_utilizadores WHERE username = ? OR email = ?");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && password_verify($password, $user['senha_hash'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['tipo'] = $user['tipo'];
                $_SESSION['nome'] = $user['nome_completo'];
                
                // Se for requisição AJAX, já foi tratada acima
                // Se for POST normal, redirecionar
                if ($_SERVER['HTTP_X_REQUESTED_WITH'] != 'XMLHttpRequest') {
                    header('Location: admin/dashboard.html');
                    exit;
                }
            }
        } catch (PDOException $e) {
            // Erro
        }
    }
}
?>