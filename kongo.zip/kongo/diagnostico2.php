<?php
header('Content-Type: text/html; charset=utf-8');
echo "<pre style='background:#0a0a0a; color:#00ff00; font-family:monospace; padding:20px; font-size:13px;'>";
echo "🔍 DIAGNÓSTICO 2 - CONEXÃO CORRIGIDA\n";
echo "====================================\n\n";

// 1. Mostrar o conteúdo COMPLETO do database.php
echo "📄 Conteúdo completo de api/config/database.php:\n";
echo str_repeat("-", 50) . "\n";
$dbFile = __DIR__ . '/api/config/database.php';
if (file_exists($dbFile)) {
    $content = file_get_contents($dbFile);
    // Ocultar senhas
    $content = preg_replace('/([\'\"])(password|pass|senha|pwd)\1\s*[,=]\s*[\'"][^\'"]*[\'"]/i', '$1$2$1 => \'***\'', $content);
    echo htmlspecialchars($content) . "\n";
} else {
    echo "❌ Arquivo não encontrado!\n";
}
echo str_repeat("-", 50) . "\n\n";

// 2. Incluir o arquivo e tentar encontrar a função
echo "🔌 Tentando conectar...\n";
require_once $dbFile;

// Verificar quais funções foram definidas
$funcoes = get_defined_functions()['user'];
$funcoesDB = array_filter($funcoes, function($f) use ($dbFile) {
    $ref = new ReflectionFunction($f);
    return strpos($ref->getFileName(), 'database.php') !== false;
});

echo "   Funções encontradas no database.php:\n";
if (count($funcoesDB) > 0) {
    foreach ($funcoesDB as $f) {
        echo "   - $f()\n";
    }
} else {
    echo "   Nenhuma função encontrada.\n";
}
echo "\n";

// 3. Tentar chamar a função de conexão
$pdo = null;
$nomesComuns = ['getDB', 'getConnection', 'connect', 'conectar', 'conexao', 'db', 'banco', 'getPdo', 'getPDO'];

foreach ($nomesComuns as $nome) {
    if (function_exists($nome)) {
        echo "   ✅ Chamando função: $nome()\n";
        try {
            $pdo = $nome();
            if ($pdo instanceof PDO) {
                echo "   ✅ Conexão PDO estabelecida com sucesso!\n\n";
                break;
            }
        } catch (Exception $e) {
            echo "   ❌ Erro: " . $e->getMessage() . "\n";
        }
    }
}

if (!$pdo) {
    echo "   ❌ Não foi possível estabelecer conexão.\n";
    echo "   💡 Copie o conteúdo do database.php acima e me envie.\n";
    echo "</pre>";
    exit;
}

// 4. Listar usuários
echo "👥 Utilizadores na tabela cong_utilizadores:\n";
echo str_repeat("-", 50) . "\n";
try {
    $stmt = $pdo->query("SELECT id, nome_completo, email, tipo, status FROM cong_utilizadores ORDER BY id");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($users) > 0) {
        foreach ($users as $u) {
            $icon = $u['tipo'] === 'admin' ? '👑' : '👤';
            echo "   $icon [{$u['id']}] {$u['nome_completo']} | {$u['email']} | Tipo: {$u['tipo']} | Status: {$u['status']}\n";
        }
    } else {
        echo "   Nenhum utilizador encontrado.\n";
    }
} catch (Exception $e) {
    echo "   ❌ Erro: " . $e->getMessage() . "\n";
}
echo str_repeat("-", 50) . "\n\n";

// 5. Criar admin e cliente de teste
echo "🛠️ Criando contas de teste...\n\n";

// Admin
$stmt = $pdo->prepare("SELECT id FROM cong_utilizadores WHERE email = ?");
$stmt->execute(['admin@kongo.com']);
if (!$stmt->fetch()) {
    $pdo->prepare("INSERT INTO cong_utilizadores (nome_completo, email, telefone, senha_hash, tipo, status, criado_em) VALUES (?, ?, ?, ?, 'admin', 'ativo', NOW())")
        ->execute(['Administrador Kongo', 'admin@kongo.com', '911111111', password_hash('admin123', PASSWORD_DEFAULT)]);
    echo "   ✅ ADMIN criado:\n";
    echo "      Email: admin@kongo.com\n";
    echo "      Senha: admin123\n\n";
} else {
    echo "   ⚠️ Admin já existe (admin@kongo.com)\n\n";
}

// Cliente (gestor)
$stmt = $pdo->prepare("SELECT id FROM cong_utilizadores WHERE email = ?");
$stmt->execute(['cliente@kongo.com']);
if (!$stmt->fetch()) {
    $pdo->prepare("INSERT INTO cong_utilizadores (nome_completo, email, telefone, senha_hash, tipo, status, criado_em) VALUES (?, ?, ?, ?, 'gestor', 'ativo', NOW())")
        ->execute(['Cliente Teste', 'cliente@kongo.com', '922222222', password_hash('cliente123', PASSWORD_DEFAULT)]);
    echo "   ✅ CLIENTE (gestor) criado:\n";
    echo "      Email: cliente@kongo.com\n";
    echo "      Senha: cliente123\n\n";
} else {
    echo "   ⚠️ Cliente já existe (cliente@kongo.com)\n\n";
}

// 6. Testar login via API
echo "🔐 Testando login via API...\n";
echo str_repeat("-", 50) . "\n";

$testes = [
    ['email' => 'admin@kongo.com', 'senha' => 'admin123', 'tipo' => 'Admin'],
    ['email' => 'cliente@kongo.com', 'senha' => 'cliente123', 'tipo' => 'Cliente']
];

foreach ($testes as $teste) {
    echo "\n   👤 Testando {$teste['tipo']} ({$teste['email']}):\n";
    
    $loginData = json_encode(['email' => $teste['email'], 'senha' => $teste['senha']]);
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . '/api/index.php?rota=login',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $loginData,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT => 10
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);
    
    echo "   HTTP Code: $httpCode\n";
    
    if ($curlError) {
        echo "   ❌ Erro cURL: $curlError\n";
    } elseif ($response) {
        $result = json_decode($response, true);
        if ($result) {
            echo "   Resposta: " . json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
        } else {
            echo "   Resposta (raw): " . substr($response, 0, 500) . "\n";
        }
    } else {
        echo "   ❌ Sem resposta da API\n";
    }
}

echo "\n====================================\n";
echo "💡 PRÓXIMOS PASSOS:\n";
echo "1. Copie TODO o resultado acima e me envie\n";
echo "2. Tente logar com as credenciais de teste\n";
echo "3. DELETE este ficheiro após resolver\n";
echo "====================================\n";
echo "</pre>";
?>