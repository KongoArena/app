<?php
/**
 * API Principal - Kongo Arena
 * Versão corrigida - Sem erros de caminho
 */

// Configuração de erro para debug
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

// Definir caminho base
define('BASE_PATH', __DIR__);
define('ROOT_PATH', dirname(__DIR__));

// Carregar configurações com caminhos absolutos
require_once BASE_PATH . '/config/database.php';
require_once BASE_PATH . '/config/jwt.php';

// Carregar models
require_once BASE_PATH . '/models/Utilizador.php';
require_once BASE_PATH . '/models/Atleta.php';

// Carregar controllers
require_once BASE_PATH . '/controllers/AuthController.php';
require_once BASE_PATH . '/controllers/AtletaController.php';

// Carregar middleware
require_once BASE_PATH . '/middleware/Auth.php';

// ============================================================
// ROTEADOR SIMPLES
// ============================================================

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

// Array de resposta
$response = [
    'success' => false,
    'message' => 'Ação não encontrada',
    'data' => null
];

try {
    switch ($action) {
        case 'login':
            if ($method === 'POST') {
                $auth = new AuthController($pdo);
                $response = $auth->login($_POST);
            } else {
                $response['message'] = 'Método não permitido para login';
            }
            break;
            
        case 'register':
            if ($method === 'POST') {
                $auth = new AuthController($pdo);
                $response = $auth->register($_POST);
            } else {
                $response['message'] = 'Método não permitido para registro';
            }
            break;
            
        case 'me':
            if ($method === 'GET') {
                $auth = new AuthMiddleware();
                $user = $auth->validate();
                if ($user) {
                    $response = [
                        'success' => true,
                        'message' => 'Usuário autenticado',
                        'data' => $user
                    ];
                } else {
                    $response = [
                        'success' => false,
                        'message' => 'Token inválido ou expirado',
                        'data' => null
                    ];
                }
            } else {
                $response['message'] = 'Método não permitido';
            }
            break;
            
        case 'atletas':
            if ($method === 'GET') {
                $atleta = new AtletaController($pdo);
                $response = $atleta->listar();
            } else if ($method === 'POST') {
                $atleta = new AtletaController($pdo);
                $response = $atleta->criar($_POST);
            } else {
                $response['message'] = 'Método não permitido';
            }
            break;
            
        case 'health':
            // Endpoint de saúde para verificar se a API está funcionando
            $response = [
                'success' => true,
                'message' => 'API está funcionando!',
                'data' => [
                    'php_version' => phpversion(),
                    'timestamp' => date('Y-m-d H:i:s'),
                    'status' => 'OK'
                ]
            ];
            break;
            
        default:
            $response['message'] = 'Ação inválida: ' . $action;
            break;
    }
} catch (Exception $e) {
    $response = [
        'success' => false,
        'message' => 'Erro interno: ' . $e->getMessage(),
        'data' => null
    ];
}

// Retornar JSON
echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
exit;