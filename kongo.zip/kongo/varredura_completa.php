<?php
/**
 * VARREDURA COMPLETA - Kongo Arena
 * Testa: Login, Index, Cliente e API
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = $_SERVER['HTTP_HOST'];
$base_url = "http://$host/kongo/";

echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>🔍 VARREDURA COMPLETA - Kongo Arena</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            background: #0a0a1a; 
            color: #eee; 
            font-family: 'Courier New', monospace; 
            padding: 20px;
        }
        .container { 
            max-width: 1200px; 
            margin: 0 auto; 
        }
        h1 { 
            color: #e94560; 
            text-align: center;
            font-size: 32px;
            margin-bottom: 10px;
        }
        .subtitle {
            text-align: center;
            color: #4fc3f7;
            margin-bottom: 30px;
        }
        .card {
            background: #16213e;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            border-left: 4px solid #4fc3f7;
        }
        .card.danger { border-left-color: #e94560; }
        .card.success { border-left-color: #4ecca3; }
        .card.warning { border-left-color: #f5a623; }
        .card-title {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 15px;
            color: #4fc3f7;
        }
        .card.danger .card-title { color: #e94560; }
        .card.success .card-title { color: #4ecca3; }
        .card.warning .card-title { color: #f5a623; }
        .status {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
        }
        .status.ok { background: #1b5e20; color: #4ecca3; }
        .status.error { background: #4a0a0a; color: #e94560; }
        .status.warning { background: #4a3a0a; color: #f5a623; }
        .status.info { background: #0a2a4a; color: #4fc3f7; }
        .box {
            background: #0f3460;
            padding: 15px;
            border-radius: 8px;
            margin-top: 10px;
            overflow: auto;
        }
        pre {
            background: #0a0a1a;
            padding: 15px;
            border-radius: 8px;
            overflow: auto;
            font-size: 13px;
            color: #4fc3f7;
        }
        .grid-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        @media (max-width: 768px) {
            .grid-2 { grid-template-columns: 1fr; }
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #0f3460;
        }
        th {
            color: #4fc3f7;
            font-weight: bold;
        }
        td {
            color: #ccc;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            color: #666;
            font-size: 12px;
        }
        .badge {
            display: inline-block;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 11px;
        }
        .badge-ok { background: #1b5e20; color: #4ecca3; }
        .badge-error { background: #4a0a0a; color: #e94560; }
        .badge-warning { background: #4a3a0a; color: #f5a623; }
    </style>
</head>
<body>
<div class='container'>
    <h1>🔍 VARREDURA COMPLETA</h1>
    <p class='subtitle'>Kongo Arena - Diagnóstico Total</p>
    <p style='text-align:center;color:#888;margin-bottom:20px;'>
        📅 Data: " . date('d/m/Y H:i:s') . " | 🌐 Host: $host
    </p>
    <hr style='border-color:#0f3460;margin-bottom:30px;'>";

// ============================================================
// FUNÇÃO PARA TESTAR URL
// ============================================================
function testar_url($url, $descricao) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $start_time = microtime(true);
    $response = curl_exec($ch);
    $end_time = microtime(true);
    $time = round(($end_time - $start_time) * 1000);
    
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $content_type = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $error = curl_error($ch);
    curl_close($ch);
    
    return [
        'url' => $url,
        'descricao' => $descricao,
        'http_code' => $http_code,
        'time' => $time,
        'content_type' => $content_type,
        'error' => $error,
        'response' => $response,
        'success' => ($http_code >= 200 && $http_code < 400 && empty($error))
    ];
}

// ============================================================
// 1. TESTAR PÁGINAS HTML
// ============================================================
echo "<h2 style='color:#4fc3f7;margin-top:30px;'>📄 1. TESTANDO PÁGINAS HTML</h2>
<div class='grid-2'>";

$paginas_html = [
    ['url' => $base_url . 'admin/login.html', 'nome' => 'Login (admin/login.html)'],
    ['url' => $base_url . 'admin/index.html', 'nome' => 'Index Admin (admin/index.html)'],
    ['url' => $base_url . 'admin/dashboard.html', 'nome' => 'Dashboard (admin/dashboard.html)'],
    ['url' => $base_url . 'cliente/login.html', 'nome' => 'Login Cliente (cliente/login.html)'],
    ['url' => $base_url . 'cliente/index.html', 'nome' => 'Index Cliente (cliente/index.html)'],
    ['url' => $base_url . 'cliente/dashboard.html', 'nome' => 'Dashboard Cliente (cliente/dashboard.html)'],
];

foreach ($paginas_html as $pagina) {
    $teste = testar_url($pagina['url'], $pagina['nome']);
    $status = $teste['success'] ? 'ok' : 'error';
    $status_text = $teste['success'] ? '✅ ONLINE' : '❌ OFFLINE';
    $status_color = $teste['success'] ? '#4ecca3' : '#e94560';
    
    echo "<div class='card " . ($teste['success'] ? 'success' : 'danger') . "'>";
    echo "<div class='card-title'>" . $pagina['nome'] . "</div>";
    echo "<p><span class='status " . $status . "'>$status_text</span></p>";
    echo "<p style='font-size:13px;color:#888;'>";
    echo "📍 URL: <a href='" . $teste['url'] . "' target='_blank' style='color:#4fc3f7;'>" . $teste['url'] . "</a><br>";
    echo "📊 HTTP: " . $teste['http_code'] . " | ⏱️ " . $teste['time'] . "ms";
    if ($teste['content_type']) {
        echo " | 📦 " . $teste['content_type'];
    }
    if ($teste['error']) {
        echo "<br>❌ Erro: " . $teste['error'];
    }
    echo "</p>";
    
    // Mostrar preview do HTML
    if ($teste['success'] && strlen($teste['response']) < 5000) {
        echo "<div class='box'>";
        echo "<details>";
        echo "<summary style='color:#4fc3f7;cursor:pointer;'>📄 Visualizar HTML</summary>";
        echo "<pre>" . htmlspecialchars(substr($teste['response'], 0, 2000)) . "</pre>";
        echo "</details>";
        echo "</div>";
    }
    echo "</div>";
}

echo "</div>";

// ============================================================
// 2. TESTAR API
// ============================================================
echo "<h2 style='color:#4fc3f7;margin-top:30px;'>🌐 2. TESTANDO API</h2>
<div class='grid-2'>";

$endpoints_api = [
    ['url' => $base_url . 'api/index.php?action=health', 'nome' => 'Health Check'],
    ['url' => $base_url . 'api/index.php', 'nome' => 'API Root'],
    ['url' => $base_url . 'api/index.php?action=login', 'nome' => 'Login Endpoint (GET)'],
];

foreach ($endpoints_api as $endpoint) {
    $teste = testar_url($endpoint['url'], $endpoint['nome']);
    $status = $teste['success'] ? 'ok' : 'error';
    $status_text = $teste['success'] ? '✅ ONLINE' : '❌ OFFLINE';
    
    echo "<div class='card " . ($teste['success'] ? 'success' : 'danger') . "'>";
    echo "<div class='card-title'>" . $endpoint['nome'] . "</div>";
    echo "<p><span class='status " . $status . "'>$status_text</span></p>";
    echo "<p style='font-size:13px;color:#888;'>";
    echo "📍 URL: <a href='" . $teste['url'] . "' target='_blank' style='color:#4fc3f7;'>" . $teste['url'] . "</a><br>";
    echo "📊 HTTP: " . $teste['http_code'] . " | ⏱️ " . $teste['time'] . "ms";
    if ($teste['content_type']) {
        echo " | 📦 " . $teste['content_type'];
    }
    echo "</p>";
    
    // Mostrar resposta da API
    if ($teste['response']) {
        echo "<div class='box'>";
        echo "<details>";
        echo "<summary style='color:#4fc3f7;cursor:pointer;'>📄 Resposta da API</summary>";
        // Tentar formatar JSON
        $json = json_decode($teste['response'], true);
        if ($json) {
            echo "<pre>" . json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
        } else {
            echo "<pre>" . htmlspecialchars(substr($teste['response'], 0, 1000)) . "</pre>";
        }
        echo "</details>";
        echo "</div>";
    }
    echo "</div>";
}

echo "</div>";

// ============================================================
// 3. TESTAR ARQUIVOS FÍSICOS
// ============================================================
echo "<h2 style='color:#4fc3f7;margin-top:30px;'>📁 3. VERIFICANDO ARQUIVOS FÍSICOS</h2>
<div class='card'>";

$arquivos = [
    'admin/login.html',
    'admin/index.html',
    'admin/dashboard.html',
    'cliente/login.html',
    'cliente/index.html',
    'cliente/dashboard.html',
    'api/index.php',
    'api/config/database.php',
    'api/config/jwt.php',
    'api/controllers/AuthController.php',
    'api/models/Utilizador.php',
    'api/middleware/Auth.php',
    '.htaccess'
];

echo "<table>";
echo "<tr><th>Arquivo</th><th>Status</th><th>Tamanho</th><th>Última Modificação</th></tr>";
foreach ($arquivos as $arquivo) {
    $caminho = __DIR__ . '/' . $arquivo;
    if (file_exists($caminho)) {
        $tamanho = number_format(filesize($caminho) / 1024, 2) . ' KB';
        $data = date('d/m/Y H:i:s', filemtime($caminho));
        echo "<tr>
                <td style='color:#4fc3f7;'>$arquivo</td>
                <td><span class='badge badge-ok'>✅ Encontrado</span></td>
                <td>$tamanho</td>
                <td>$data</td>
              </tr>";
    } else {
        echo "<tr>
                <td style='color:#e94560;'>$arquivo</td>
                <td><span class='badge badge-error'>❌ Não encontrado</span></td>
                <td>-</td>
                <td>-</td>
              </tr>";
    }
}
echo "</table>";
echo "</div>";

// ============================================================
// 4. TESTAR BANCO DE DADOS
// ============================================================
echo "<h2 style='color:#4fc3f7;margin-top:30px;'>🗄️ 4. TESTANDO BANCO DE DADOS</h2>
<div class='card'>";

try {
    require_once __DIR__ . '/api/config/database.php';
    
    if (isset($pdo) && $pdo instanceof PDO) {
        echo "<p><span class='status ok'>✅ Conectado ao banco</span></p>";
        
        // Listar tabelas
        $stmt = $pdo->query("SHOW TABLES");
        $tabelas = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        echo "<p><strong>📋 Tabelas encontradas (" . count($tabelas) . "):</strong></p>";
        echo "<div class='box'>";
        foreach ($tabelas as $tabela) {
            $stmt = $pdo->query("SELECT COUNT(*) as total FROM $tabela");
            $total = $stmt->fetch()['total'];
            echo "<span style='color:#4ecca3;'>✅ $tabela</span> - <span style='color:#888;'>$total registros</span><br>";
        }
        echo "</div>";
        
        // Verificar usuários
        if (in_array('cong_utilizadores', $tabelas)) {
            $stmt = $pdo->query("SELECT id, username, email, tipo FROM cong_utilizadores");
            $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo "<p><strong>👥 Usuários cadastrados:</strong></p>";
            echo "<div class='box'>";
            foreach ($usuarios as $user) {
                echo "🆔 {$user['id']} | 👤 {$user['username']} | 📧 {$user['email']} | 🏷️ {$user['tipo']}<br>";
            }
            echo "</div>";
        }
    }
} catch (Exception $e) {
    echo "<p><span class='status error'>❌ Erro no banco: " . $e->getMessage() . "</span></p>";
}

echo "</div>";

// ============================================================
// 5. TESTAR LOGIN REAL
// ============================================================
echo "<h2 style='color:#4fc3f7;margin-top:30px;'>🔐 5. TESTANDO LOGIN REAL</h2>
<div class='card'>";

// Testar login via API
$login_data = ['username' => 'admin', 'password' => 'admin123'];
$ch = curl_init($base_url . 'api/index.php?action=login');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($login_data));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "<p><strong>Testando login com admin/admin123</strong></p>";
echo "<p>HTTP Code: " . ($http_code == 200 ? "<span style='color:#4ecca3;'>200 OK</span>" : "<span style='color:#e94560;'>$http_code ERRO</span>") . "</p>";

if ($response) {
    $json = json_decode($response, true);
    if ($json && isset($json['success']) && $json['success']) {
        echo "<p><span class='status ok'>✅ Login funcionando!</span></p>";
        if (isset($json['data']['token'])) {
            echo "<p>🔑 Token JWT: <span style='color:#4fc3f7;font-size:12px;'>" . substr($json['data']['token'], 0, 50) . "...</span></p>";
        }
    } else {
        echo "<p><span class='status error'>❌ Login falhou!</span></p>";
        if ($json && isset($json['message'])) {
            echo "<p>Mensagem: " . $json['message'] . "</p>";
        }
    }
    echo "<div class='box'>";
    echo "<details>";
    echo "<summary style='color:#4fc3f7;cursor:pointer;'>📄 Resposta completa</summary>";
    echo "<pre>" . json_encode(json_decode($response), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
    echo "</details>";
    echo "</div>";
}

echo "</div>";

// ============================================================
// 6. RESUMO FINAL
// ============================================================
echo "<h2 style='color:#4fc3f7;margin-top:30px;'>📊 6. RESUMO DA VARREDURA</h2>
<div class='card success'>";

echo "<div class='grid-2'>";
echo "<div>";
echo "<h3 style='color:#4ecca3;'>✅ O que está funcionando:</h3>";
echo "<ul style='color:#aaa;list-style:none;'>";
echo "<li>✅ Banco de dados conectado</li>";
echo "<li>✅ Arquivos principais existem</li>";
echo "<li>✅ Tabelas do sistema criadas</li>";
if (isset($usuarios) && count($usuarios) > 0) {
    echo "<li>✅ Usuários cadastrados: " . count($usuarios) . "</li>";
}
echo "</ul>";
echo "</div>";

echo "<div>";
echo "<h3 style='color:#f5a623;'>⚠️ Pontos de atenção:</h3>";
echo "<ul style='color:#aaa;list-style:none;'>";
// Verificar arquivos HTML que faltam
$html_faltando = [];
foreach ($paginas_html as $pagina) {
    $teste = testar_url($pagina['url'], '');
    if (!$teste['success']) {
        $html_faltando[] = $pagina['nome'];
    }
}
if (count($html_faltando) > 0) {
    echo "<li>❌ Páginas HTML faltando: " . implode(', ', $html_faltando) . "</li>";
} else {
    echo "<li>✅ Todas as páginas HTML existem</li>";
}
echo "</ul>";
echo "</div>";
echo "</div>";

echo "<div style='margin-top:20px;background:#0f3460;padding:15px;border-radius:8px;'>";
echo "<p style='color:#4fc3f7;'><strong>🔑 Credenciais para teste:</strong></p>";
echo "<p>👤 Usuário: <strong style='color:#4ecca3;'>admin</strong></p>";
echo "<p>🔑 Senha: <strong style='color:#4ecca3;'>admin123</strong></p>";
echo "</div>";

echo "</div>";

// ============================================================
// FOOTER
// ============================================================
echo "
<hr style='border-color:#0f3460;margin:30px 0;'>
<div class='footer'>
    <p>🔍 Varredura concluída em " . date('d/m/Y H:i:s') . "</p>
    <p>Kongo Arena - Sistema de Diagnóstico v1.0</p>
    <p>💡 <a href='login_emergencia.php' style='color:#4fc3f7;'>Acessar Login de Emergência</a></p>
</div>

</div>
</body>
</html>";
?>