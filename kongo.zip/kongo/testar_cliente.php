<?php
/**
 * Script de Teste - Criar Conta de Cliente (Gestor)
 * Kongo Arena - TanqueDigital
 */

header('Content-Type: text/html; charset=utf-8');
echo "<pre style='background:#1a1a1a; color:#00ff00; font-family:monospace; padding:30px; font-size:14px;'>";
echo "🧪 TESTE: Criar Conta de Cliente\n";
echo "================================\n\n";

// Tentar carregar as configurações do banco
if (file_exists(__DIR__ . '/api/config/database.php')) {
    $pdo = require __DIR__ . '/api/config/database.php';
    if (!($pdo instanceof PDO)) {
        $config = $pdo;
        $dsn = "mysql:host={$config['host']};dbname={$config['db']};charset=utf8mb4";
        $pdo = new PDO($dsn, $config['user'], $config['pass']);
    }
} else {
    die("❌ Ficheiro 'api/config/database.php' não encontrado!\n");
}

// Dados do novo cliente (Gestor)
$novoCliente = [
    'nome_completo' => 'João Silva - Cliente Teste',
    'email' => 'joao@teste.com',
    'telefone' => '923456789',
    'senha' => '123456',
    'tipo' => 'gestor',
    'status' => 'ativo'
];

// Verificar se já existe
$stmt = $pdo->prepare("SELECT id, email FROM cong_utilizadores WHERE email = ?");
$stmt->execute([$novoCliente['email']]);
$existente = $stmt->fetch();

if ($existente) {
    echo "⚠️ Utilizador já existe!\n";
    echo "   ID: {$existente['id']}\n";
    echo "   Email: {$existente['email']}\n\n";
    echo "💡 Tente outro email ou apague este utilizador primeiro.\n";
} else {
    // Criar hash da senha
    $senhaHash = password_hash($novoCliente['senha'], PASSWORD_DEFAULT);
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO cong_utilizadores 
            (nome_completo, email, telefone, senha_hash, tipo, status, criado_em) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $novoCliente['nome_completo'],
            $novoCliente['email'],
            $novoCliente['telefone'],
            $senhaHash,
            $novoCliente['tipo'],
            $novoCliente['status']
        ]);
        
        $novoId = $pdo->lastInsertId();
        
        echo "✅ CLIENTE CRIADO COM SUCESSO!\n\n";
        echo "📋 Dados de Acesso:\n";
        echo "   ID: $novoId\n";
        echo "   Nome: {$novoCliente['nome_completo']}\n";
        echo "   Email: {$novoCliente['email']}\n";
        echo "   Senha: {$novoCliente['senha']}\n";
        echo "   Tipo: {$novoCliente['tipo']}\n\n";
        
        echo "🔐 Agora vá para 'login.html' e teste:\n";
        echo "   Email: {$novoCliente['email']}\n";
        echo "   Senha: {$novoCliente['senha']}\n\n";
        
        echo "📌 Este utilizador deve ser redirecionado para 'cliente.html'\n";
        
    } catch (PDOException $e) {
        echo "❌ Erro ao criar utilizador:\n";
        echo "   " . $e->getMessage() . "\n";
    }
}

echo "\n================================\n";
echo "🗑️ DELETE este ficheiro após o teste!\n";
echo "================================\n";
echo "</pre>";
?>