<?php
header('Content-Type: text/html; charset=utf-8');
echo "<pre style='background:#0a0a0a; color:#00ff00; font-family:monospace; padding:20px;'>";
echo "🚀 SETUP FINAL - KONGO ARENA\n";
echo "============================\n\n";

// 1. Conectar ao banco
require_once __DIR__ . '/api/config/database.php';

try {
    $pdo = getDBConnection();
    echo "✅ Conexão com banco OK!\n\n";
} catch (Exception $e) {
    die("❌ Erro: " . $e->getMessage() . "\n");
}

// 2. Listar usuários atuais
echo "👥 Utilizadores atuais:\n";
$stmt = $pdo->query("SELECT id, nome_completo, email, tipo, status FROM cong_utilizadores ORDER BY id");
$users = $stmt->fetchAll();
foreach ($users as $u) {
    $icon = $u['tipo'] === 'admin' ? '👑' : '👤';
    echo "   $icon [{$u['id']}] {$u['email']} ({$u['tipo']})\n";
}
echo "\n";

// 3. Criar Admin
echo "👑 Criando ADMIN...\n";
$stmt = $pdo->prepare("SELECT id FROM cong_utilizadores WHERE email = ?");
$stmt->execute(['admin@kongo.com']);
if ($stmt->fetch()) {
    $pdo->prepare("UPDATE cong_utilizadores SET senha_hash = ? WHERE email = ?")
        ->execute([password_hash('admin123', PASSWORD_DEFAULT), 'admin@kongo.com']);
    echo "   ✅ Admin atualizado (senha redefinida)\n";
} else {
    $pdo->prepare("INSERT INTO cong_utilizadores (nome_completo, email, telefone, senha_hash, tipo, status, criado_em) VALUES (?, ?, ?, ?, 'admin', 'ativo', NOW())")
        ->execute(['Administrador Kongo', 'admin@kongo.com', '911111111', password_hash('admin123', PASSWORD_DEFAULT)]);
    echo "   ✅ Admin criado\n";
}

// 4. Criar Cliente (gestor)
echo "\n👤 Criando CLIENTE (Gestor)...\n";
$stmt = $pdo->prepare("SELECT id FROM cong_utilizadores WHERE email = ?");
$stmt->execute(['cliente@kongo.com']);
if ($stmt->fetch()) {
    $pdo->prepare("UPDATE cong_utilizadores SET senha_hash = ? WHERE email = ?")
        ->execute([password_hash('cliente123', PASSWORD_DEFAULT), 'cliente@kongo.com']);
    echo "   ✅ Cliente atualizado (senha redefinida)\n";
} else {
    $pdo->prepare("INSERT INTO cong_utilizadores (nome_completo, email, telefone, senha_hash, tipo, status, criado_em) VALUES (?, ?, ?, ?, 'gestor', 'ativo', NOW())")
        ->execute(['Gestor Clube Teste', 'cliente@kongo.com', '922222222', password_hash('cliente123', PASSWORD_DEFAULT)]);
    echo "   ✅ Cliente criado\n";
}

// 5. Criar também um atleta para teste
echo "\n⚽ Criando ATLETA...\n";
$stmt = $pdo->prepare("SELECT id FROM cong_utilizadores WHERE email = ?");
$stmt->execute(['atleta@kongo.com']);
if ($stmt->fetch()) {
    $pdo->prepare("UPDATE cong_utilizadores SET senha_hash = ? WHERE email = ?")
        ->execute([password_hash('atleta123', PASSWORD_DEFAULT), 'atleta@kongo.com']);
    echo "   ✅ Atleta atualizado\n";
} else {
    $pdo->prepare("INSERT INTO cong_utilizadores (nome_completo, email, telefone, senha_hash, tipo, status, criado_em) VALUES (?, ?, ?, ?, 'atleta', 'ativo', NOW())")
        ->execute(['Atleta Teste', 'atleta@kongo.com', '933333333', password_hash('atleta123', PASSWORD_DEFAULT)]);
    echo "   ✅ Atleta criado\n";
}

// 6. Testar login
echo "\n🔐 TESTANDO LOGIN...\n";
echo str_repeat("=", 50) . "\n";

require_once __DIR__ . '/api/models/Utilizador.php';

$utilizador = new Utilizador();

$testes = [
    ['email' => 'admin@kongo.com', 'senha' => 'admin123', 'esperado' => 'admin'],
    ['email' => 'cliente@kongo.com', 'senha' => 'cliente123', 'esperado' => 'gestor'],
    ['email' => 'atleta@kongo.com', 'senha' => 'atleta123', 'esperado' => 'atleta'],
];

foreach ($testes as $t) {
    echo "\n📧 Testando: {$t['email']}\n";
    $resultado = $utilizador->login($t['email'], $t['senha']);
    
    if ($resultado['success'] ?? false) {
        $tipo = $resultado['utilizador']['tipo'] ?? $resultado['user']['tipo'] ?? '?';
        $redirecionar = ($tipo === 'admin') ? 'index.html' : 'cliente.html';
        echo "   ✅ SUCESSO! Tipo: $tipo\n";
        echo "   🎯 Será redirecionado para: $redirecionar\n";
        if (isset($resultado['token'])) {
            echo "   🔑 Token: " . substr($resultado['token'], 0, 40) . "...\n";
        }
    } else {
        echo "   ❌ FALHOU: " . ($resultado['message'] ?? 'Erro desconhecido') . "\n";
    }
}

echo "\n============================\n";
echo "🎉 SETUP CONCLUÍDO!\n\n";
echo "📋 CREDENCIAIS DE TESTE:\n\n";
echo "👑 ADMIN (vai para index.html):\n";
echo "   Email: admin@kongo.com\n";
echo "   Senha: admin123\n\n";
echo "👤 GESTOR (vai para cliente.html):\n";
echo "   Email: cliente@kongo.com\n";
echo "   Senha: cliente123\n\n";
echo "⚽ ATLETA (vai para cliente.html):\n";
echo "   Email: atleta@kongo.com\n";
echo "   Senha: atleta123\n\n";
echo "⚠️ DELETE este ficheiro após testar!\n";
echo "============================\n";
echo "</pre>";
?>