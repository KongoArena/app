<?php
/**
 * VER ESTRUTURA DA TABELA - Kongo Arena
 */

// Configuração do banco
$host = 'myshared2003';
$dbname = 'luna_home';
$user = 'luna_home';
$pass = 'Akiles1539@@##';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("❌ Erro de conexão: " . $e->getMessage());
}

echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>📋 Estrutura da Tabela - Kongo Arena</title>
    <style>
        body { background: #0a0a1a; color: #eee; font-family: 'Courier New', monospace; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; background: #16213e; padding: 30px; border-radius: 15px; }
        h1 { color: #e94560; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #0f3460; }
        th { color: #4fc3f7; }
        .highlight { background: #0f3460; }
        .success { color: #4ecca3; }
        .error { color: #e94560; }
        .box { background: #0f3460; padding: 15px; border-radius: 8px; margin: 10px 0; }
    </style>
</head>
<body>
<div class='container'>
    <h1>📋 ESTRUTURA DA TABELA: cong_utilizadores</h1>";

// Verificar se a tabela existe
$stmt = $pdo->query("SHOW TABLES LIKE 'cong_utilizadores'");
if ($stmt->rowCount() == 0) {
    echo "<p class='error'>❌ Tabela cong_utilizadores NÃO EXISTE!</p>";
    echo "<p><strong>Criando tabela automaticamente...</strong></p>";
    
    // Criar tabela
    $sql = "CREATE TABLE cong_utilizadores (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        nome VARCHAR(100),
        tipo ENUM('admin', 'cliente', 'funcionario') DEFAULT 'cliente',
        status ENUM('ativo', 'inativo') DEFAULT 'ativo',
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($sql);
    echo "<p class='success'>✅ Tabela criada com sucesso!</p>";
    
    // Inserir admin
    $senha = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO cong_utilizadores (username, email, password, nome, tipo) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute(['admin', 'admin@kongo.com', $senha, 'Administrador', 'admin']);
    echo "<p class='success'>✅ Usuário admin criado (senha: admin123)</p>";
}

// Buscar estrutura da tabela
$stmt = $pdo->query("DESCRIBE cong_utilizadores");
$colunas = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h2>📊 Colunas da tabela:</h2>";
echo "<table>";
echo "<tr><th>Campo</th><th>Tipo</th><th>Nulo</th><th>Chave</th><th>Padrão</th><th>Extra</th></tr>";
foreach ($colunas as $coluna) {
    echo "<tr>";
    echo "<td><strong>" . $coluna['Field'] . "</strong></td>";
    echo "<td>" . $coluna['Type'] . "</td>";
    echo "<td>" . $coluna['Null'] . "</td>";
    echo "<td>" . $coluna['Key'] . "</td>";
    echo "<td>" . ($coluna['Default'] ?? 'NULL') . "</td>";
    echo "<td>" . $coluna['Extra'] . "</td>";
    echo "</tr>";
}
echo "</table>";

// Mostrar dados existentes
echo "<h2>👥 Usuários cadastrados:</h2>";
$stmt = $pdo->query("SELECT * FROM cong_utilizadores");
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($usuarios) > 0) {
    echo "<div class='box'>";
    foreach ($usuarios as $user) {
        echo "🆔 {$user['id']} | ";
        echo "👤 " . ($user['username'] ?? $user['email'] ?? 'N/A') . " | ";
        echo "📧 {$user['email']} | ";
        echo "🏷️ {$user['tipo']} | ";
        echo "📅 {$user['criado_em']}<br>";
    }
    echo "</div>";
} else {
    echo "<p class='error'>❌ Nenhum usuário cadastrado!</p>";
}

// Sugestão de correção
echo "<h2>🛠️ Sugestões:</h2>";
echo "<div class='box'>";
echo "<p><strong>Se a coluna 'username' não existir, pode ser que o campo se chame:</strong></p>";
echo "<ul style='color:#aaa;'>";
echo "<li>📌 <strong>usuario</strong></li>";
echo "<li>📌 <strong>nome_usuario</strong></li>";
echo "<li>📌 <strong>login</strong></li>";
echo "<li>📌 <strong>email</strong> (usando email como login)</li>";
echo "</ul>";
echo "</div>";

// Botão para corrigir
echo "<hr>";
echo "<p><strong>🔧 Clique no botão abaixo para corrigir automaticamente:</strong></p>";
echo "<form method='POST'>";
echo "<button type='submit' name='corrigir' style='background:#e94560;color:#fff;border:none;padding:12px 30px;border-radius:8px;font-size:16px;cursor:pointer;'>🛠️ Corrigir Tabela</button>";
echo "</form>";

// Processar correção
if (isset($_POST['corrigir'])) {
    echo "<h2>🛠️ Aplicando correções...</h2>";
    
    // Verificar se a coluna username existe
    $stmt = $pdo->query("SHOW COLUMNS FROM cong_utilizadores LIKE 'username'");
    if ($stmt->rowCount() == 0) {
        // Adicionar coluna username
        try {
            $pdo->exec("ALTER TABLE cong_utilizadores ADD COLUMN username VARCHAR(50) AFTER id");
            echo "<p class='success'>✅ Coluna 'username' adicionada!</p>";
            
            // Atualizar usernames existentes baseado no email
            $pdo->exec("UPDATE cong_utilizadores SET username = SUBSTRING_INDEX(email, '@', 1) WHERE username IS NULL");
            echo "<p class='success'>✅ Usernames atualizados!</p>";
        } catch (PDOException $e) {
            echo "<p class='error'>❌ Erro: " . $e->getMessage() . "</p>";
        }
    } else {
        echo "<p class='success'>✅ Coluna 'username' já existe!</p>";
    }
    
    echo "<p><strong>🔑 Credenciais:</strong> admin / admin123</p>";
    echo "<p><a href='login_emergencia.php' style='color:#4fc3f7;'>🔐 Acessar Login de Emergência</a></p>";
}

echo "</div></body></html>";
?>