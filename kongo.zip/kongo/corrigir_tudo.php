<?php
/**
 * CORREÇÃO AUTOMÁTICA - Kongo Arena
 */

echo "<h1>🔧 Corrigindo Kongo Arena...</h1>";

// 1. Corrigir api/index.php
$index_content = '<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
header("Content-Type: application/json");

define("BASE_PATH", __DIR__);
define("ROOT_PATH", dirname(__DIR__));

require_once BASE_PATH . "/config/database.php";
require_once BASE_PATH . "/config/jwt.php";
require_once BASE_PATH . "/models/Utilizador.php";
require_once BASE_PATH . "/controllers/AuthController.php";
require_once BASE_PATH . "/middleware/Auth.php";

$action = $_GET["action"] ?? "";
$method = $_SERVER["REQUEST_METHOD"];

$response = ["success" => false, "message" => "Ação não encontrada"];

try {
    switch($action) {
        case "health":
            $response = ["success" => true, "message" => "API OK!", "data" => ["status" => "online"]];
            break;
        case "login":
            if ($method === "POST") {
                $auth = new AuthController($pdo);
                $response = $auth->login($_POST);
            }
            break;
        default:
            $response["message"] = "Ação: " . $action;
    }
} catch (Exception $e) {
    $response = ["success" => false, "message" => $e->getMessage()];
}

echo json_encode($response, JSON_PRETTY_PRINT);
?>';

file_put_contents(__DIR__ . '/api/index.php', $index_content);
echo "✅ api/index.php corrigido<br>";

// 2. Corrigir .htaccess
$htaccess = "RewriteEngine On\nRewriteCond %{REQUEST_FILENAME} !-f\nRewriteCond %{REQUEST_FILENAME} !-d\nRewriteRule ^(.*)$ api/index.php [QSA,L]";
file_put_contents(__DIR__ . '/.htaccess', $htaccess);
echo "✅ .htaccess criado<br>";

echo "<h2>✅ CORREÇÃO CONCLUÍDA!</h2>";
echo "<p>Acesse: <a href='/kongo/api/index.php?action=health'>/kongo/api/index.php?action=health</a></p>";
echo "<p><strong>Login de emergência:</strong> <a href='/kongo/login_emergencia.php'>/kongo/login_emergencia.php</a></p>";
echo "<p>Usuário: <strong>admin</strong> | Senha: <strong>admin123</strong></p>";
?>